#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){

    a.setPosition(0,0,0);
    b.setParent(a);
    b.setPosition(200,0,0);
    c.setParent(b);
    c.setPosition(0,100,0);
}

//--------------------------------------------------------------
void ofApp::update(){

    a.panDeg(1);
    b.rollDeg( 4 * sin(ofGetElapsedTimef()));
    
    line.addVertex(c.getGlobalPosition());
    
}

//--------------------------------------------------------------
void ofApp::draw(){

    
    cam.begin();
    a.draw();
    b.draw();
    c.draw();
    ofLine(a.getGlobalPosition(), b.getGlobalPosition());
    ofLine(b.getGlobalPosition(), c.getGlobalPosition());
    
    line.draw();
    cam.end();
    
    
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

    line.clear();
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
